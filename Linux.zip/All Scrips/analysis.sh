#!/bin/bash

grep $1 Dealer_schedule | grep $2 | awk -F" " '{print $1,$2,$5,$6}' >> Dealers_working_during_losses



