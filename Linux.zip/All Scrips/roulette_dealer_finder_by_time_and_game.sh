#!/bin/bash

read -p 'Please enter the start of the work week (4 digit date, Monday): ' "week"
read -p 'Please enter a 4 digit date: ' "date"
read -p 'Please enter a 2 digit hour: ' "hour" 
read -p 'Was this AM or PM? ' "AMPM"

cat -e ~/Documents/Homework/Lucky_Duck_Investigation/Roulette_Loss_Investigation/Dealer_Analysis/Dealer_Schedules_${week}/${date}_Dealer_schedule | grep -e $hour | grep -e $ampm > temp

cat temp

read -p 'What game are you searching for?
(A) Blackjack
(B) Routlette
(C) Texas Hold-em
-- ' "game" 

if [ "$game" = "A" ]
then cat temp | awk F" " '{print $3,$4}'

elif [ "$game" = "B" ]
then cat temp | awk -F" " '{print $5,$6}'

elif [ "$game" = "C" ]
then cat temp | awk -F" " '{print $7,$8}'

fi
