#!/bin/bash

sudo free -m > ~/backups/freemem/free_mem.txt
sudo du > ~/backups/diskuse/disk_usage.txt
sudo lsof > ~/backups/openlist/open_list.txt     
sudo df > ~/backups/freedisk/free_disk.txt

