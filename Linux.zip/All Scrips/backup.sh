sudo tar cvf home.tar home > var/backup/home.tar
sudo mv var/backup/home.tar var/backup/home12012020.var
sudo ls -lah var/backup/ >> var/backup/file_report.txt
sudo free -h >> var/backup

